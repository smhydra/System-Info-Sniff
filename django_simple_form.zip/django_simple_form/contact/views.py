from django.shortcuts import render
from .forms import ContactForm

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()  # This actually writes to the DB
            return render(request, 'contact/success.html', {'name': form.cleaned_data.get('name')})
    else:
        form = ContactForm()
    return render(request, 'contact/form.html', {'form': form})
